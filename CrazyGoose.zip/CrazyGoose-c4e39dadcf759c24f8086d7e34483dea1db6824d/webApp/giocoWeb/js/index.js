let game = new CrazyGoose()
game.start()